This is the fully documented source code of our packet viewer for Roblox Studio. If you don't want to compile the source code, that's ok! We provide the pre-compiled PacketViewer.dll.

To compile the code using GCC, run `g++ main.cpp -shared -o b.dll` from the root directory.

To use the DLL, you'll want to use a DLL injector. The one we used was "Process Hacker" which is like a super-powered Task Manager. The download link for windows 7-11 is "https://sourceforge.net/projects/processhacker/files/processhacker2/processhacker-2.39-setup.exe/download". Once you have it downloaded and open, locate roblox studio. Once found, right click it, click Miscellaneous, then Inject DLL, then select PacketViewer.dll. If you did everything correctly, you should see a console window appear. This console window will print all packets starting with the bytes 0x8307.

If you resize the console window, studio will freeze until you press ENTER inside the console window. If studio is becoming unresponsive or nothing is being printed, just press ENTER and you should be fine.