#pragma once

#include <windows.h>

#include "Utility.h"
#include "Types.h"


/*
	Hooks a virtual function in a VFTable. Returns the original function pointer. To hook a virtual function, we replace the pointer in the VFTable with our own function. We then call the original function pointer in our function.

	vftablePtr: The VFTable to hook into
	position: The position of the virtual function in the VFTable
	func: The function to replace the virtual function with
*/
static inline void* VFTable_hook(void** vftablePtr, int position, void* func)
{
	// VirtualProtect is a windows function used to change the permissions of the section. We use it to make the section writable so we can change the pointer in the VFTable without causing an access violation and alerting David Baszucki.
	int oldSetting;
	VirtualProtect(vftablePtr, position * sizeof(void*), PAGE_READWRITE, (PDWORD) &oldSetting);

	// Hotswap the function pointer in the VFTable; the actual hooking part.
	void* oldFunc = vftablePtr[position];
	vftablePtr[position] = func;

	// Restore the original permissions of the section.
	VirtualProtect(vftablePtr, position * sizeof(void*), oldSetting, (PDWORD) &oldSetting);

	return oldFunc;
}

// An image is an executable mapped into memory.

/*
	Searches for a VFTable in the given image. Returns NULL if not found.

	base: The base address of the image to search in
	name: The mangled name of the class to find the VFTable to search for
	size: The size of the name in bytes
*/
static inline void** VFTable_find(void* base, char* mangled_name, size_t size)
{
	// Parses the header, finds every section, searches for the mangled name in each section, and returns the global start address of the mangled name in the section.
	char* result = Utility_findInImage(base, mangled_name, size);
	if (result == NULL) return NULL;

	/*
		Every mangled name is part of a larger set of data called the type descriptor. The type descriptor is a struct in memory with a pointer to the to the std::type_info's VFTable, a field/section containing the mangled name of the class.
	*/

	// This is an 32-bit base offset, so we treat it a little specially. There are always two pointers (16 bytes) between the start of the type descriptor and the start of the mangled name. We subtract 0x10 to get the start of the type descriptor, and then we subtract the base address of the image to get the IBO of the type descriptor. :pepe_evil:
	unsigned int ibo_type_descriptor = (uintptr_t) result - (uintptr_t) base - 0x10;

	/*
		The Complete Object Locator contains the 32bit Image Base Offset (IBO), or pointer, to the type descriptor relative to the image base.
	*/

	// The COL always contains the IBO of the type descriptor 0xC bytes after its starting address. We first find the IBO of the type descriptor, and then search again to "cross reference" the IBO in this section which contains the COL, and then we subtract by 0xC to get the start of the COL.
	char* completeObjLoc = Utility_findInImage(base, (char*) &ibo_type_descriptor, 4) - 0xC;

	// We want to find the VFTable to begin our hooking shenanigans. There is always a global pointer to the associated COL before the start of the VFTable. We search *again* to "cross reference" the COL in this section which contains the VFTable, and then we add 8 to get the start of the VFTable.
	char* vftable = Utility_findInImage(base, (char*) &completeObjLoc, 8) + 8;

	return (void**) vftable;
}