#include <windows.h>
#include <stdlib.h>
#include <stdio.h>

#include "VFTable.h"
#include "Types.h"

// This typedef for the target virtual function we are overriding; we will call it the "Receive" function.
typedef void (*ReceiveFunc)(void*, char);

// A global pointer to the original receive function before we override it (so roblox doesn't die)
ReceiveFunc original_Receive;

// A mutex lock to prevent multiple threads from accessing the queue at the same time. The original function does this, so we are too for safety / completeness sake.
CRITICAL_SECTION ReceiveLock;

// A global pointer to the VFTable we are hooking into
void** vftable;

void Receive(RakNet_RakPeer* rakPeer, char _)
{
	// EnterCriticalSection is a windows function that acts as a mutex. The original unhooked function locked the mutex before accessing the queue, so we do too.
	EnterCriticalSection(&ReceiveLock);

	// We find each packet in the rakPeer queue and print it to the console. We only care about packets with the ID 0x8307. We first listened to all packets and fired remote events, looking for how they appear in the console. Then we examined the 2016 roblox source code to verify remote events use the 0x8307 packet ID. We figured out the data types by looking at the disassembly of the current roblox studio executable, and cross referencing the data types with the data types with RakNet's documentation, aware that roblox's RakNet version is heavily modified.
	for (int i = rakPeer->queue.head; i < rakPeer->queue.tail; i++)
	{
		RakNet_Packet* packet = rakPeer->queue.array[i];

		// There is a lot of noise in the console, so we only print the packets we care about. We only care about packets with the ID 0x8307.
		if (packet->data[0] == 0x83 && packet->data[1] == 0x07)
		{
			// This is how we guarantee we print the entire packet, and everything related to the packet.
			for (int j = 0; j < packet->size; j++)
			{
				printf("%02x ", packet->data[j]);
			}

			printf("\n\n");
		}
	}

	// Must unlock the mutex after we are done accessing the queue.
	LeaveCriticalSection(&ReceiveLock);

	// Call the original receive function so roblox doesn't die
	return original_Receive(rakPeer, _);
}

/*
	hinstDLL is a handle to the DLL module. The value is the base address of the DLL. The HINSTANCE of the DLL is the same as the HMODULE of the DLL, so hinstDLL can be used in subsequent calls to the GetModuleFileName, GetModuleHandle, or GetProcAddress function to get information about the DLL and to call exported DLL functions.

	fwdReason is a flag that tells us why this function is being called. We only care about DLL_PROCESS_ATTACH and DLL_PROCESS_DETACH

	lpvReserved is reserved for future use. It is NULL for dynamic loads and nonnull for static loads.
*/
BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{

	switch (fdwReason) {
		case DLL_PROCESS_ATTACH:
			// A windows function that initializes a critical section object. This is used to prevent multiple threads from accessing the queue at the same time.
			InitializeCriticalSection(&ReceiveLock);

			// A windows function. New console time
			AllocConsole();
			freopen_s((FILE**)stdout, "CONOUT$", "w", stdout);

			/*
				GetModuleHangle is a windows function that returns a handle to the module specified by the name of the module. In this case, we are getting a handle to the current module (the DLL).

				VFTable_find is a function that searches the module for a VFTable with the specified name and size.

				".?AVRakPeer@RakNet@@" was derived from finding the mangled name in the executable using Ghidra.
			*/
			vftable = VFTable_find(GetModuleHandle(NULL), ".?AVRakPeer@RakNet@@", 20);
			if (vftable == NULL)
			{
				printf("Unable to locate VFTable address!\n");
				return FALSE;
			};

			// Here we go, hooking the function.
			original_Receive = (ReceiveFunc) VFTable_hook(vftable, 23, (void*) &Receive);
			break;

		case DLL_PROCESS_DETACH:
			if (vftable == NULL) return TRUE;

			// Unhook the function so roblox doesn't die
			VFTable_hook(vftable, 23, (void*) original_Receive);
			break;
	}

	return TRUE;
}