#pragma once

#include <windows.h>

#include "Types.h"

// Every operating system has an executable format, and every executable uses that format to store information about itself. This is called the PE format on windows. Every executable stores metadata about itself in a PE header.

/*
	section: The start address of the section to search for in the executable's header
	sectionSize: The size of the section in bytes
	match: The piece of data to search for in the section
	matchSize: The size of the data to search for in bytes
*/
static inline char* Utility_findInSection(char* section, size_t sectionSize, char* match, size_t matchSize)
{
	for (char* i = section; i - section < sectionSize; i++)
	{
		for (int j = 0; j < matchSize; j++)
		{
			if (i[j] != match[j]) break;
			if (j == matchSize - 1) return i;
		}
	}

	return NULL;
}

/*
	Searches for a match through every section defined in the header of an image. Returns NULL if not found. https://images-ext-2.discordapp.net/external/s7iBlyt7acMhCreBHzweWC2IDMLdbOXvWnok1K9A6Bg/https/i.stack.imgur.com/0DdKh.png

	base: The base address of the image to search in
	match: The piece of data to search for in the executable's header
	size: The size of the data to search for in bytes
*/
static inline char* Utility_findInImage(void* base, char* match, size_t size)
{
	IMAGE_DOS_HEADER* dos = (IMAGE_DOS_HEADER*) base;
	IMAGE_NT_HEADERS64* coff = (IMAGE_NT_HEADERS64*) (dos->e_lfanew + (uintptr_t) base);
	IMAGE_SECTION_HEADER* sections = (IMAGE_SECTION_HEADER*) ((uintptr_t) &coff->OptionalHeader + coff->FileHeader.SizeOfOptionalHeader);

	for (int i = 0; i < coff->FileHeader.NumberOfSections; i++)
	{
		char* result = Utility_findInSection((char*) (sections[i].VirtualAddress + (uintptr_t) base), sections[i].Misc.VirtualSize, match, size);

		if (result != NULL) return result;
	}

	return NULL;
}